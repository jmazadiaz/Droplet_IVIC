
clear a_T_O_ a_ini_ a_end_

clear a_end_i_ a_in_ a_table_ a_archivo_ %inicio de secci�n A

clear a_i_ a_img_ a2_img_ a_bw_ a_cc_ a_sa2max a_sa2maxpos ...
    a_drop_ a_cen_ a_des_ a_diameters_ %Calculo de las variables

clear a_radio_ a_x_ a_y1 a_y2 a_x_% Show data
 