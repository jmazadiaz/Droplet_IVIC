
%  imshow(imread('D:\Droplets Video\glicerina\48 cm\AVI\IMG\img-g48-1\f007.jpg'));

hold on

plot(centro(1),centro(2), 'b*')
plot(xy_(:,1),xy_(:,2))
plot(xy_(:,4),xy_(:,5))