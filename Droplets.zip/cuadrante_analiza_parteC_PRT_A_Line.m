%% Parte del c�digo cuadrante_analiza_parteC.m ----> Simplificar c�digo.    Salida ln1_max1_ -> ln1_max8_ -> ln3_max8_
% Voy a trabajar solo con los primeros 5 octantes
ln1_max1_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L1(:,1),Num_pxline_);   
ln1_max2_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L2(:,1),Num_pxline_);
ln1_max3_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L3(:,1),Num_pxline_);                    
ln1_max4_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L4(:,1),Num_pxline_);
ln1_max5_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L5(:,1),Num_pxline_);
% ln1_max6_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L6(:,1),Num_pxline_);
% ln1_max7_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L7(:,1),Num_pxline_);
% ln1_max8_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L8(:,1),Num_pxline_);
                                 %%
                                 
ln2_max1_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L1(:,2),Num_pxline_);
ln2_max2_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L2(:,2),Num_pxline_);
ln2_max3_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L3(:,2),Num_pxline_);                    
ln2_max4_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L4(:,2),Num_pxline_);
ln2_max5_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L5(:,2),Num_pxline_);
% ln2_max6_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L6(:,2),Num_pxline_);
% ln2_max7_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L7(:,2),Num_pxline_);
% ln2_max8_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L8(:,2),Num_pxline_);
                                 %%
                                 
ln3_max1_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L1(:,3),Num_pxline_);
ln3_max2_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L2(:,3),Num_pxline_);
ln3_max3_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L3(:,3),Num_pxline_);                    
ln3_max4_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L4(:,3),Num_pxline_);
ln3_max5_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L5(:,3),Num_pxline_);
% ln3_max6_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L6(:,3),Num_pxline_);
% ln3_max7_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L7(:,3),Num_pxline_);
% ln3_max8_ = linea_menor2max(Partes{i_,3}(j_).Radios(k_).L8(:,3),Num_pxline_);
                                 