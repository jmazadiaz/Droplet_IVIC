%%      ANALISIS DEL TARGET PAR ABORRAR

    clear d_i1_ d_i1_bw1_ d_i1_bw2_ d_cc1_ d_d_cc2_ d_is1max d_is1maxpos ...
       d_is2max d_is2maxpos d_p_target_ d_target_ d_i1bw_ptarget_ ...
       d_i1bw_target_ d_se_ d_i1pt_dilate_ d_i1t_dilate_

    clear d_i_ d_i2_  d_moda_  d_max_ d_min_ d_med_ d_Target_    % INICIO DE PARTE D

    clear d_figi2_ d_hbw_ d_ibw_ d_icc is2max is2maxpos

    clear d_iframe_ d_ini_ d_nun_cc_ d_T_bw_ d_T1_bw1_ ...
          d_T1_bw2_ d_T_O_ d_valor_     % VARIABLES AL PRINCIPIO