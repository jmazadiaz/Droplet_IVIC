clear b_T_O_ b_ini_ b_end_

clear b_end_i b_in_

clear b_i_ b_img_ b2_img_ b_bw_ b_cc_ b_sa2max b_sa2maxpos...
      b_drop_ b_cen_ b_des_ b_diameters_

clear b_centroids_ b_radio_ b_x b_y1 b_y2 b_x