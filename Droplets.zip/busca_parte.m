%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   
%   Este script es para explorar las partes de cada v�deo  en el conjunto de
%   imagenes extraidas de los videos
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
clear
% clc
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%         CONTROL PRINCIPAL                          %%
%%
    caso = 1;                                                                   % Caso de estudio
    video = 1;                                                                  % Video a analizar(1,2,...,30)
    
    folder_Lfold_ = strcat(...
           '/home/maza/AllMeida/Dropbox/Droplets/Matlab/Droplets/folders');     %Recore el diretorio
    filetype_fold_ = 'mat';% Formato de archivo folders
    filetype_imag_ = 'jpg';% Formato de imagen

    caso_fluid_vel_ = leedir(folder_Lfold_, filetype_fold_ );
    
    clear folder_drops_ filetype_drops_
    
   load(caso_fluid_vel_{caso})                                                  % Caso ( fluido+altura ) [Abre la lista de video]
    
   archivo_ = leedir(folders_{video},filetype_imag_);
   
   %% 
    
    ind_ = 1;
    part_ = 1;
    
%%    
    nun_cc_ = 4;    %(4o8)specifies the desired connectivivty for the connected components
    T_bw_ = 70;     % Maximo valor en binarizaci�n
    inv_ = true;    %Inverso del binarizaci�nm
    T_O_= 50;       %Numero de pixels para objetos grandes en la imagen
    a_=6.875533829; % �rea del target en mm^2
    
%%    

    i=imread(archivo_{ind_});    % Arriba  ind_
    j=imread(archivo_{ind_+1});
    k=imread(archivo_{ind_+2});
    
    i2=rgb2gray(i);
    j2=rgb2gray(j);
    k2=rgb2gray(k);
    
    ibw_=binarizacion(i2,T_bw_,inv_);    %Ariba T_bw_ inv_
    jbw_=binarizacion(j2,T_bw_,inv_);
    kbw_=binarizacion(k2,T_bw_,inv_);
    
    icc=bwconncomp(ibw_, nun_cc_);
    jcc=bwconncomp(jbw_, nun_cc_);
    kcc=bwconncomp(kbw_, nun_cc_);

    [is2max, is2maxpos]=objectMaxSize(icc,T_O_);  % Arriba T_O_
    [js2max, js2maxpos]=objectMaxSize(jcc,T_O_); 
    [ks2max, ks2maxpos]=objectMaxSize(kcc,T_O_); 

    ibw1 = object(ibw_,icc.PixelIdxList{is2maxpos(part_)});
    jbw1 = object(jbw_,jcc.PixelIdxList{js2maxpos(part_)});
    kbw1 = object(kbw_,kcc.PixelIdxList{ks2maxpos(part_)});
    
    ibw2 = object(ibw_,icc.PixelIdxList{is2maxpos(part_+1)});
    jbw2 = object(jbw_,jcc.PixelIdxList{js2maxpos(part_+1)});
    kbw2 = object(kbw_,kcc.PixelIdxList{ks2maxpos(part_+1)});

%     [imm2Xpx,immXpx,iTperimeter] = area(ibw1,a_);% calcula la relaci�n pixel mm target
%     [jmm2Xpx,jmmXpx,jTperimeter] = area(jbw1,a_);
%     [kmm2Xpx,kmmXpx,kTperimeter] = area(kbw1,a_);
    
    [iTcentroids,iTradii] = centre(ibw1);
    [jTcentroids,jTradii] = centre(jbw1);
    [kTcentroids,kTradii] = centre(kbw1);
    
    [i2Tcentroids,i2Tradii] = centre(ibw2);
    [j2Tcentroids,j2Tradii] = centre(jbw2);
    [k2Tcentroids,k2Tradii] = centre(kbw2);
    
   close
   %%
    figure
    shg
    L = 1920;
    W = 1000;
    a=1;
    b=1;
    set(gcf,'position',[a b L W])
    %%
    subplot(3,3,1)
    imshow(i2)
    hold on
    plot(iTcentroids(1),iTcentroids(2),'*b')
    title(['Carpeta ',video,num2str(caso)])
    subplot(3,3,2)
    imshow(ibw1)
    hold on
    plot(iTcentroids(1),iTcentroids(2),'*b')
    title(['Imagen ',num2str(ind_)])
    subplot(3,3,3)
    imshow(ibw2)
    hold on
    plot(i2Tcentroids(1),i2Tcentroids(2),'*b')
    title(['Numero de objetos: ',num2str(icc.NumObjects)])
    %%
    subplot(3,3,4)
    imshow(j2)
    hold on
    plot(jTcentroids(1),jTcentroids(2),'*r')
    title(['Carpeta ',video,num2str(caso)])
    subplot(3,3,5)
    imshow(jbw1)
    hold on
    plot(jTcentroids(1),jTcentroids(2),'*r')
    title(['Imagen ',num2str(ind_+1)])
    subplot(3,3,6)
    imshow(jbw2)
    hold on
    plot(i2Tcentroids(1),i2Tcentroids(2),'*r')
    title(['Numero de objetos: ',num2str(jcc.NumObjects)])
    %%
    subplot(3,3,7)
    imshow(k2)
    hold on
    plot(kTcentroids(1),kTcentroids(2),'*g')
    title(['Carpeta ',video,num2str(caso)])
    subplot(3,3,8)
    imshow(kbw1)
    hold on
    plot(kTcentroids(1),kTcentroids(2),'*g')
    title(['Imagen ',num2str(ind_+2)])
    subplot(3,3,9)
    imshow(kbw2)
    hold on
    plot(i2Tcentroids(1),i2Tcentroids(2),'*g')
    title(['Numero de objetos: ',num2str(kcc.NumObjects)])
    %%
    
    
    
    