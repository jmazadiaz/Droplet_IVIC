clear c_T_O_ c_T_vent_ c_octantes_ c_end_ c_end_i_ c_ini_

clear c_end_i c_in_ c_archivo_  % INICIO DE PARTE C

clear c_i_ c_img_ c2_img_ c_bw_ c_cc_ c_sa2max c_sa2maxpos...
      c_drop_ c_radios_ c_cen_ c_des_ c_diameters_
  
clear c_centroids_ c_radio_ c_x c_y1 c_y2 c_x c_table_