function [y]=tateagua(radio, tsuper)
y=(2*pi*tsuper(3))/977,67538861216)*radio;
end