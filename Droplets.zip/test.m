disp(strcat(mesg1_,num2str(h_), mesg11_, num2str(length(folders_)), '    -->' ,mesg2_,num2str(porcentaje2_), ' %'));
disp(strcat(mesg1_,num2str(h_), mesg11_, num2str(length(folders_)), '    -->' ,mesg2_,num2str(porcentaje2_), ' %'));
disp(strcat(mesg1_,num2str(h_), mesg11_, num2str(length(folders_)), '    -->' ,mesg2_,num2str(porcentaje2_), ' %'));
fprintf(strcat(mesg1_,num2str(h_), mesg11_, num2str(length(folders_)), '    -->' ,mesg2_,num2str(porcentaje2_), ' %'));
