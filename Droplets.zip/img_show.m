load(g78-.mat)
load(mat\g78-.mat)
 filetype_drops_ = 'jpg';





for i_ = 1: length(indices_)

folder_drops_ = folders_{i_};
archivo_ = leedir(folder_drops_, filetype_drops_ );

indices_{i_}

%% 	PARTE A indices 3 y 4

