%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   
%       object.m
%   Input
%      
%   Output
%
% Corregir la esfericidad de cada mancha de tinta. Usando una 